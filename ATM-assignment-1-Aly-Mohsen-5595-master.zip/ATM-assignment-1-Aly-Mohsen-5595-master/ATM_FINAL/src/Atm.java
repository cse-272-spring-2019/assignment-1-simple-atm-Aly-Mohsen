
public class Atm {
	public static void main(String[] args) {
	}

}
